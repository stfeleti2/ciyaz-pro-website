CIYAZ PRO APPROVED PROJECT IMAGE PACK

These photos and original neon artwork were supplied in the Ciyaz Pro conversations.

To publish on GitHub Pages:
1. Download this ZIP.
2. Upload the single ZIP file into the ROOT of the stfeleti2/ciyaz-pro-website GitHub repository on branch main.
3. Rename it exactly ciyaz-original-photos.zip if needed.
4. GitHub Actions automatically extracts photos into assets/ during deployment.

Do NOT unzip the archive in GitHub manually unless you prefer the images to live directly in the assets folder.
If working locally, unzip into the site root so the assets/ files are available.

Files: poster.avif (the actual poster supplied in the conversation), wet-wild-title.avif (crop of its neon lettering), pool.avif, gathering.avif, patio.avif (the actual Leondale venue photographs supplied in the project).
Original photos / lettering remain identifiable. AVIF optimization keeps the site fast and small.
